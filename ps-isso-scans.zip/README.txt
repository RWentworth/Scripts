
BACKGROUND
These Windows Powershell scripts are created by Trevor Bryant and Richard Wentworth of Phacil, Inc for the CA\ISSO. The ps-isso.ps1 will identify the operating system, server roles, and other applications and call the necessary scripts to perform the scanning for the respective Security Configuration Standards checklists.

INSTRUCTIONS
1)	If the location does not exist, create C:\ps-scripts on the server to be scanned.
2)	Place the ps-isso-scans.zip into C:\ps-scripts and unzip to this location.
3)	Open Windows Powershell as Administrator
4)	Execute ps-isso.ps1 by entering "C:\ps-scripts\ps-isso.ps1" and pressing enter.
5)	Collection results and remove ALL the .ps1 scripts if they did not automatically get removed.
